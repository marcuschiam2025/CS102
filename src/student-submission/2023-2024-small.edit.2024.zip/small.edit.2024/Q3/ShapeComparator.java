/*
 * Name: Small Edit
 * Email ID: small.edit.2024
 */

import java.util.*;   

public class ShapeComparator{

    
}
