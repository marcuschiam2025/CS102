/*
 * Name: Rename Trick
 * Email ID: rename.trick.2024
 */

import java.util.*;   

public class ShapeComparator{

    
}
