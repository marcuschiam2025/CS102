/*
 * Name: Honest Coder
 * Email ID: honest.coder.2024
 */

import java.util.*;   

public class ShapeComparator{

    
}
