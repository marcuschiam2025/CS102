/*
 * Name: Copy Cat
 * Email ID: copy.cat.2024
 */

import java.util.*;   

public class ShapeComparator{

    
}
