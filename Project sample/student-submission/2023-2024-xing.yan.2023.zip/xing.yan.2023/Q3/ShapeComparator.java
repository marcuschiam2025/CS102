/*
 * Name: Yan xing
 * Email ID: xing.yan.2023
 */

import java.util.*;   

public class ShapeComparator{

    
}
