/*
 * Name: Teo Chee
 * Email ID: chee.teo.2022
 */

import java.util.*;   

public class ShapeComparator{
    public ShapeComparator(Shape a, Shape b){

    }
    
}
